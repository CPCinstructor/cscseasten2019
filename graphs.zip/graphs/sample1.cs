using System;
using System.Windows.Forms;
using System.Drawing;

public class Form1 : Form 
{
 int x1, y1, x2, y2;
 PaintEventArgs k = null;

 public Form1() 
 {
  x1 = y1 = x2 = y2 = 100;
  this.Paint += new PaintEventHandler(Form1_Paint);
  this.KeyDown += new KeyEventHandler(Form1_KeyDown);    
 }       
 
 private void Form1_Paint(object sender, PaintEventArgs pe) 
 {
  Graphics g = this.CreateGraphics();
  Pen myPen = new Pen(Color.Black, 1);

  g.DrawLine(myPen, x1, y1, x2, y2);
 }
 
 private void Form1_KeyDown(object sender, KeyEventArgs e) 
 {
  x1 = x2;
  y1 = y2;

  switch (e.KeyCode) 
  {
   case Keys.Left: x2--; break;
   case Keys.Right: x2++; break;
   case Keys.Up: y2--; break;
   case Keys.Down: y2++; break;   
  }
  
  Form1_Paint(this, k);
 }
 
 [STAThread]
 public static void Main() 
 {
  Application.Run(new Form1());
 }
}
