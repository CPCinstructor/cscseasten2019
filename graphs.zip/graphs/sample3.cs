using System;
using System.Windows.Forms;
using System.Drawing;

public class Form1 : Form {

 int degree = 0;
 TrackBar trackBar1;
 
 public PointF[] getEllipseXY(double x, double y, int a, int b, int _alpha, int _theta) {
  PointF[] points = new PointF[360];
 
  // Angle is given by Degree Value
  double theta = _theta * (Math.PI / 180); //(Math.PI/180) converts Degree Value into Radians
  double sintheta = Math.Sin(theta);
  double costheta = Math.Cos(theta);
 
  for (int i = 0; i < 360; i++) 
  {
    double alpha = i * (Math.PI / 180) ;
    double sinalpha = Math.Sin(alpha);
    double cosalpha = Math.Cos(alpha);
 
    points[i].X = (float)(x + (a * cosalpha * costheta - b * sinalpha * sintheta));
    points[i].Y = (float)(y + (a * cosalpha * sintheta + b * sinalpha * costheta));

  }
  
  return points;
 }

 public Form1() {
 
  trackBar1 = new TrackBar();
  trackBar1.Location = new Point(10, 220);
  trackBar1.Size = new Size(265, 35);
  trackBar1.Scroll += new EventHandler(this.trackBar1_Scroll);
  trackBar1.Minimum = 0;
  trackBar1.Maximum = 360;
  trackBar1.SmallChange = 1;
  Controls.Add(trackBar1);
  
  this.Paint += new PaintEventHandler(this.Form1_Paint);
 }

 private void Form1_Paint(Object sender, PaintEventArgs e) {
  Graphics g = this.CreateGraphics();

  Pen myPen = new Pen(Color.Red);
  g.DrawPolygon(myPen, getEllipseXY(100, 100, 25, 10, 60, degree));
 }

 private void trackBar1_Scroll(object sender, EventArgs e) {
  degree = trackBar1.Value;
  this.Refresh();
 }

 [STAThread]
 public static void Main() {
  Application.Run(new Form1());
 }

}
