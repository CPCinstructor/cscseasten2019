using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

public partial class Form1 : Form {
 private PictureBox picCanvas;
 private Button btnDraw;
 private Label label1;
 private Label label2;
 private Label label3; 
 private NumericUpDown nSides;
 private NumericUpDown nRadius;
 private NumericUpDown nAngle;
 
 public Form1() {
  this.picCanvas = new PictureBox();
  this.nSides = new NumericUpDown();  
  this.btnDraw = new Button();
  this.label1 = new Label();
  this.label2 = new Label();
  this.label3 = new Label();
  this.nRadius = new NumericUpDown();
  this.nAngle = new NumericUpDown();
  this.SuspendLayout();
  // 
  // picCanvas
  // 
  this.picCanvas.BorderStyle = BorderStyle.FixedSingle;
  this.picCanvas.Location = new Point(11, 72);
  this.picCanvas.Name = "picCanvas";
  this.picCanvas.Size = new Size(423, 307);
  this.picCanvas.TabIndex = 0;
  this.picCanvas.TabStop = false;
  // 
  // label1
  // 
  this.label1.AutoSize = true;
  this.label1.Location = new Point(11, 8);
  this.label1.Name = "label1";
  this.label1.Text = "Sides";
  // 
  // label2
  // 
  this.label2.AutoSize = true;
  this.label2.Location = new Point(107, 8);
  this.label2.Name = "label2";
  this.label2.Text = "Radius";
  // 
  // label3
  // 
  this.label3.AutoSize = true;
  this.label3.Location = new Point(188, 7);
  this.label3.Name = "label3";
  this.label3.Text = "Angle";
  // 
  // btnDraw
  // 
  this.btnDraw.AutoSize = true;  
  this.btnDraw.Location = new Point(354, 24);
  this.btnDraw.Name = "btnDraw";
  this.btnDraw.Text = "Draw";
  this.btnDraw.UseVisualStyleBackColor = true;
  this.btnDraw.Click += new System.EventHandler(this.btnDraw_Click);
  // 
  // nSides
  // 
  this.nSides.Location = new Point(14, 35);
  this.nSides.Minimum = new decimal(new int[] {3, 0, 0, 0});
  this.nSides.Name = "nSides";
  this.nSides.Size = new Size(67, 22);
  this.nSides.Value = new decimal(new int[] {3, 0, 0, 0});  
  //   
  // nRadius
  // 
  this.nRadius.Location = new Point(107, 35);
  this.nRadius.Maximum = new decimal(new int[] {1000, 0, 0, 0});
  this.nRadius.Minimum = new decimal(new int[] {10, 0, 0, 0});
  this.nRadius.Name = "nRadius";
  this.nRadius.Size = new Size(57, 22);
  this.nRadius.Value = new decimal(new int[] {100, 0, 0, 0});
  // 
  // nAngle
  // 
  this.nAngle.Location = new Point(190, 35);
  this.nAngle.Maximum = new decimal(new int[] {360, 0, 0, 0});
  this.nAngle.Name = "nAngle";
  this.nAngle.Size = new Size(61, 22);
  // 
  // Form1
  // 
  this.AutoScaleDimensions = new SizeF(6F, 13F);
  this.AutoScaleMode = AutoScaleMode.Font;
  this.ClientSize = new Size(445, 410);
  this.Controls.Add(this.nAngle);
  this.Controls.Add(this.nRadius);
  this.Controls.Add(this.label3);
  this.Controls.Add(this.label2);
  this.Controls.Add(this.btnDraw);
  this.Controls.Add(this.label1);
  this.Controls.Add(this.nSides);
  this.Controls.Add(this.picCanvas);
  this.FormBorderStyle = FormBorderStyle.FixedSingle;
  this.MaximizeBox = false;
  this.Text = "Regular Polygon Drawing"; 
  this.ResumeLayout(false);
  this.PerformLayout();
 }

 private void btnDraw_Click(object sender, EventArgs e) {
  int sides = (int)nSides.Value;
  int radius = (int)nRadius.Value;
  int angle = (int)nAngle.Value;

  Point center = new Point(picCanvas.Width / 2, picCanvas.Height / 2);

  Image disposeMe = picCanvas.Image;
  picCanvas.Image = DrawRegularPolygon(sides, radius, angle, center, picCanvas.ClientSize);
  if (disposeMe != null)
  disposeMe.Dispose();
 }

 private Bitmap DrawRegularPolygon(int sides, int radius, int startingAngle, Point center, Size canvasSize) {
  //Get the location for each vertex of the polygon
  Point[] verticies = CalculateVertices(sides, radius, startingAngle, center);

  //Render the polygon
  Bitmap polygon = new Bitmap(canvasSize.Width, canvasSize.Height);
  using (Graphics g = Graphics.FromImage(polygon))
  {
  g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
  g.DrawPolygon(Pens.Black, verticies);
  }

  return polygon;
 }

 private Point[] CalculateVertices(int sides, int radius, int startingAngle, Point center)
 {
  if (sides < 3)
  throw new ArgumentException("Polygon must have 3 sides or more.");

  List<Point> points = new List<Point>();
  float step = 360.0f / sides;

  float angle = startingAngle; //starting angle
  for (double i = startingAngle; i < startingAngle + 360.0; i += step) //go in a circle
  {
  points.Add(DegreesToXY(angle, radius, center));
  angle += step;
  }

  return points.ToArray();
 }

 private Point DegreesToXY(float degrees, float radius, Point origin)
 {
  Point xy = new Point();
  double radians = degrees * Math.PI / 180.0;

  xy.X = (int)(Math.Cos(radians) * radius + origin.X);
  xy.Y = (int)(Math.Sin(-radians) * radius + origin.Y);

  return xy;
 }
    
 [STAThread]
 public static void Main() {
  Application.Run(new Form1());
 }
}
