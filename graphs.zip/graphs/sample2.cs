using System;
using System.Windows.Forms;
using System.Drawing;

public class Form1 : Form {

 Vector2[] vt;
 Point[] pt;
 
 public Form1() {

  this.Paint += new PaintEventHandler(this.Form1_Paint);

  Timer timer1 = new Timer();
  timer1.Tick += new EventHandler(this.timer1_Tick);
  timer1.Interval = 100;
  timer1.Start();
  
  pt = new Point[] { new Point(100,100), new Point(150,150), new Point(200,200) };  
  vt = new Vector2[] { new Vector2(1,1), new Vector2(1,-1), new Vector2(-1,1) };
 }


 private void Form1_Paint(Object sender, PaintEventArgs e) {
  Graphics g = this.CreateGraphics();

  Pen myPen = new Pen(Color.Red);
  g.DrawPolygon(myPen, pt);
 }

 private void timer1_Tick(Object sender, EventArgs e) {
  for (int i=0; i<pt.Length; i++) {
   pt[i] = Vector2.Add(vt[i], pt[i]);
  }
  this.Refresh();
 }

 [STAThread]
 public static void Main() {
  Application.Run(new Form1());
 }

}
