
//Filename: Vector2.cs (Vector data type for 2D)
using System;
using System.Drawing;

public struct Vector2 
{
 //struct Variables
 private double x;
 private double y;

 // Constructors
 public Vector2(double x, double y) // 2 parameters
 {
  this.x = 0;
  this.y = 0;

  X = x;
  Y = y;
 }

 public Vector2(double[] xy) 
 {
  this.x = 0;
  this.y = 0;

  Array = xy;
 }

 public Vector2(Vector2 v1) 
 {
  this.x = 0;
  this.y = 0;

  X = v1.X;
  Y = v1.Y;
 }

 // Accessors & Mutators

 public double X 
 {
  get {return x;}
  set {x = value;}
 }

 public double Y 
 {
  get {return y;}
  set {y = value;}
 }

 public double Magnitude 
 {
  get { return Math.Sqrt(this.x * this.x + this.y * this.y); }
 }

 public double[] Array  
 {
  get {return new double[] {x,y};}
  set {
   if(value.Length == 2) 
   {
    x = value[0];
    y = value[1];
   }
   else {
    throw new Exception("Need two elements, (x, y)");
   }
  }
 }

 public double this[int index] 
 {
  get {
   switch (index) {
    case 0: {return X; }
    case 1: {return Y; }
    default: throw new Exception("Index must be 0 or 1.");
   }
  }
  set {
   switch (index) {
    case 0: {X = value; break;}
    case 1: {Y = value; break;}
    default: throw new Exception("Index must be 0 or 1.");
   }
  }
 }
 
 // Operators
 public static Vector2 operator+(Vector2 v1, Vector2 v2) 
 {
  return ( new Vector2 (v1.X + v2.X, v1.Y + v2.Y) );
 }
 
 public static Point operator+(Vector2 v1, Point p1) 
 {
  return ( new Point((int)(v1.X + p1.X),(int)(v1.Y + p1.Y)) );
 }
  
 public static Vector2 Add(Vector2 v1, Vector2 v2) 
 {
  return ( new Vector2 (v1.X + v2.X, v1.Y + v2.Y) );
 }
 
 // polymorphism
 public static Point Add(Vector2 v1, Point p1) 
 {  
  return ( new Point((int)(v1.X + p1.X),(int)(v1.Y + p1.Y)) );
 }

 public static Vector2 operator-(Vector2 v1, Vector2 v2) 
 {
  return ( new Vector2 (v1.X - v2.X, v1.Y - v2.Y) );
 }
 
 public static Vector2 operator*(Vector2 v1, double n) 
 {
  return ( new Vector2 (v1.X * n, v1.Y * n) );
 }
 
 // enforce the commutative law 'scalar x vector'='vector x scalar'
 public static Vector2 operator*(double n, Vector2 v1) 
 {
  return v1 * n;
 }

  
 public static Vector2 operator/(Vector2 v1, double n) 
 {
  return ( new Vector2 (v1.X / n, v1.Y / n) );
 }
 
 public static Vector2 Division(Vector2 v1, double n) 
 {
  return ( new Vector2 (v1.X / n, v1.Y / n) );
 }
 
 
 //v1.X * v2.X + v1.Y * v2.Y + v1.z * v2.z + ....
 public static Double DotProduct(Vector2 v1, Vector2 v2) 
 {
  return (v1.X * v2.X + v1.Y * v2.Y);
 }
 
 /*
 The cross product of vector1 and vector2. The following formula is used to calculate the cross product: 
      (Vector1.X * Vector2.Y) - (Vector1.Y * Vector2.X)
 */

 public static Double CrossProduct(Vector2 v1, Vector2 v2) 
 {
 return (v1.X * v2.Y - v1.Y * v2.X);
 }
}
